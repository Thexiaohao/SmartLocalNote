SmartLocalNote V5 发布资源包 (README.txt)
==========================================

本压缩包用于测试虚拟压缩包浏览、包内单文件跳转 [[09_发布资源包.zip!README.txt]]
以及右键「一键展开内容填入」功能。

包含文件：
1. README.txt  - 本说明文档
2. config.yaml - 样例 YAML 配置
3. preview.png - 内嵌预览缩略图
